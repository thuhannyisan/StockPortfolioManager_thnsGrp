package org.global.charlie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication
@RestController
public class CharlieApplication {

    public static void main(String[] args) {
        SpringApplication.run(CharlieApplication.class, args);
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {
        if ("alice".equals(request.getUsername()) && "secret".equals(request.getPassword())) {
            return new LoginResponse("success", "dummy-token-123");
        } else {
            throw new UnauthorizedException();
        }
    }

    static class LoginRequest {
        private String username;
        private String password;

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    static class LoginResponse {
        private String status;
        private String token;

        public LoginResponse(String status, String token) {
            this.status = status;
            this.token = token;
        }

        public String getStatus() { return status; }
        public String getToken() { return token; }
    }

    @ResponseStatus(code = org.springframework.http.HttpStatus.UNAUTHORIZED)
    static class UnauthorizedException extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }
}
